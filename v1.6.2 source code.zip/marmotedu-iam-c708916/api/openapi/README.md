# `openapi`

OpenAPI specs.
