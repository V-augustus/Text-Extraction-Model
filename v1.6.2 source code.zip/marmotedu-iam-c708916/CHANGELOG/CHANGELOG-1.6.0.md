
<a name="v1.6.0"></a>
## [v1.6.0](https://github.com/marmotedu/iam/compare/v1.4.0...v1.6.0) (2021-12-21)

### Bug Fixes

* **apiserver:** do not authenticate when creating a user

### Code Refactoring

* optimize code
* support coscmd and coscli tool both
* optimize func name from `runPumps` to `pump`

