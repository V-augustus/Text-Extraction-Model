
<a name="v1.7.0"></a>
## [v1.7.0](https://github.com/marmotedu/iam/compare/v1.6.2...v1.7.0) (2022-06-16)

### Bug Fixes

* fix iam-pump cannot analyze and move authorization log to mongodb
* fix codegen failed with go1.18
* fix wrktest.sh display bug
* remove jsoniter compile tag
* fix some compile bugs
* remove gin warning message
* remove duplicated key in yaml
* grammar errors
* **apiserver:** deal with column 'LoginedAt'
* **apiserver:** fix secrets delete collection

### Code Refactoring

* remove rollinglog package

