
<a name="v0.6.1"></a>
## [v0.6.1](https://github.com/marmotedu/iam/compare/v0.6.0...v0.6.1) (2021-03-11)

