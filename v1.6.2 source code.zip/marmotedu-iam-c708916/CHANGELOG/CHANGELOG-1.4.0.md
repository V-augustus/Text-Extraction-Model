
<a name="v1.4.0"></a>
## [v1.4.0](https://github.com/marmotedu/iam/compare/v1.2.0...v1.4.0) (2021-12-19)

### Code Refactoring

* provide `ServeHealthCheck` in genericapiserver package

