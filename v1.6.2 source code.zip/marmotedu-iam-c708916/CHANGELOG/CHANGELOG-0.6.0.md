
<a name="v0.6.0"></a>
## [v0.6.0](https://github.com/marmotedu/iam/compare/v0.5.6...v0.6.0) (2021-03-11)

### Bug Fixes

* fix name bug, have Analytics struct and function at the same time
* fix initialization sequence bug

### Code Refactoring

* add code comment line
* change struct name `RedisAnalyticsHandler` to `Analytics`
* optimize RedisAnalyticsHandler struct field order
* optimize code generated file name

### Features

* switch components to use application framework

