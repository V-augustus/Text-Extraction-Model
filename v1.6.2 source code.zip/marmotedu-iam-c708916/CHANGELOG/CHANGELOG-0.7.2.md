
<a name="v0.7.2"></a>
## [v0.7.2](https://github.com/marmotedu/iam/compare/v0.7.1...v0.7.2) (2021-04-10)

