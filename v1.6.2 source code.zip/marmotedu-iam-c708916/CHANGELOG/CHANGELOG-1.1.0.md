
<a name="v1.1.0"></a>
## [v1.1.0](https://github.com/marmotedu/iam/compare/v1.0.10...v1.1.0) (2021-11-06)

### Bug Fixes

* **apiserver:** fix graceful shutdown redis bug

