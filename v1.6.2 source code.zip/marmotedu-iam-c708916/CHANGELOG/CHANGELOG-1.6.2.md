
<a name="v1.6.2"></a>
## [v1.6.2](https://github.com/marmotedu/iam/compare/v1.6.0...v1.6.2) (2021-12-22)

