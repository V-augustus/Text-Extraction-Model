# 安装Docker

安装命令如下：

```bash
$ curl -fsSL https://get.docker.com | bash -s docker --mirror aliyun
``
