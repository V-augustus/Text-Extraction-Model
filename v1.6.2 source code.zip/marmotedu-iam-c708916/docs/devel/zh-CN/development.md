## 代码贡献流程

IAM 项目采用 Github Forking 工作流：[IAM 项目代码贡献流程](./forking.md)

## 开发规范

需要通过静态代码检查工具；golangci-lint & gometalinter

## 部署

## 测试
