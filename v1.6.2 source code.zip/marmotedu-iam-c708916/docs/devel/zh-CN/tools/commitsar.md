# commitsar使用指南

## commitsar安装

```bash
go get github.com/aevea/commitsar
```

## commitsar使用

### commitsar配置

### 运行

