# `configs`

iam 组件配置模板：

+ iam-apiserver.yaml: iam-apiserver 配置文件
+ iam-authz-server.yaml: iam-authz-server 配置文件
+ config: marmotedu-sdk-go 和 iamctl 配置文件

一些配置项因为不需要被注释掉了，如有需要可自行打开。



