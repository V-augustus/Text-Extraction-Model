// Copyright 2020 Lingfei Kong <colin404@foxmail.com>. All rights reserved.
// Use of this source code is governed by a MIT style
// license that can be found in the LICENSE file.

// Package v1 is the place where you can implements more complex business logic.
package v1 // import "github.com/marmotedu/iam/internal/apiserver/service/v1"
